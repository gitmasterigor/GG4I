# LinkedInAutomator
Essa ferramenta realiza a adição de contatos no LinkedIn de Forma automática!

# Como usar?
1. Basta baixar o arquivo (zip) - como ensino no video aqui:
2. Extrair o arquivo ZIP
3. Se estiver rodando em um computador 64bits, execute e instale o VC_redist.x64.exe
4. caso tenha um computador 32bits, rode o VC_redist.x86.exe
5. Clicar no arquivo "LinkedIn Automator.exe" para abrir
6. Digite o cargo do profissional que deseja logar
7. Clique em iniciar a automação
8. Digite seus dados de login(o programa não armazena seus dados em momento algum)
9. Aguarde os 60 segundos para que o programa inicie automáticamente
10. Agora é só sair, ir tomar um café ou ir fazer qualquero outra coisa mais útil!

# Onde posso aprender a criar uma automação como essa?
Irei ensinar como criei essa automação nos próximos videos do canal https://www.youtube.com/c/DevAprender/

# Quer aprender a criar automações como essa?
Me manda uma mensagem no https://www.instagram.com/devaprender/ com a palavra "método" que te explico como posso te ajudar


